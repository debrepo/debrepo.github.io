# Sources

This is a fork of the official PHP repository which receives backport of security fixes from maintained branches.

This branch is **PHP version 7.4.33** with security fixes (see the NEWS file).

# Binary distributions

Known list of providers using this repository as sources for build of old PHP version with extended security support:

## RPM

### Fedora / RHEL / CentOS / AlmaLinux / RockyLinux

* [Remi's RPM repository](https://rpms.remirepo.net/)