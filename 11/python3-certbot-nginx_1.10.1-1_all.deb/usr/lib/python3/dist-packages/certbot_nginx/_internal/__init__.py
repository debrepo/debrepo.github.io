"""Certbot nginx plugin internal implementation."""
